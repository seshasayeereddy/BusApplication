package com.validator;

public class OperatorVerificationValidator {

}
