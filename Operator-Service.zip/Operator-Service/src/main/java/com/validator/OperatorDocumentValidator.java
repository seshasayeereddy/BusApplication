package com.validator;

public class OperatorDocumentValidator {

}
