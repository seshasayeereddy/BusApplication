package com.validator;

public class DroppingPointValidator {

}
