package com.validator;

public class BoardingPointValidator {

}
