package com.validator;

public class OperatorBankDetailValidator {

}
