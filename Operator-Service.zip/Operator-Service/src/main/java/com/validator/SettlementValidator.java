package com.validator;

public class SettlementValidator {

}
