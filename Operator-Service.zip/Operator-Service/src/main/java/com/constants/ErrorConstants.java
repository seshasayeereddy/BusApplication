package com.constants;

public class ErrorConstants {

}
