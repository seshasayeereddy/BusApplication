package com.constants;

public class ValidationConstants {

}
