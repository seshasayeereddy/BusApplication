package com.dto.request;

public class CreateBoardingPointRequest {

}
