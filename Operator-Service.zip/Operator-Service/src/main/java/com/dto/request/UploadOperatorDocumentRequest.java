package com.dto.request;

public class UploadOperatorDocumentRequest {

}
