package com.dto.request;

public class CreateDroppingPointRequest {

}
