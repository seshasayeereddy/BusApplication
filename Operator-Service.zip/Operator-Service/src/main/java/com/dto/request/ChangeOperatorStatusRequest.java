package com.dto.request;

public class ChangeOperatorStatusRequest {

}
