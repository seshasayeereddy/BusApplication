package com.dto.request;

public class CreateSettlementRequest {

}
