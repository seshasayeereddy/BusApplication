package com.dto.request;

public class CreateApiConfigRequest {

}
