package com.dto.request;

public class CreateCommissionRequest {

}
