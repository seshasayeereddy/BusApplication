package com.dto.request;

public class CreateOperatorRequest {

}
