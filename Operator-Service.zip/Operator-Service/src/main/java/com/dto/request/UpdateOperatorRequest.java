package com.dto.request;

public class UpdateOperatorRequest {

}
