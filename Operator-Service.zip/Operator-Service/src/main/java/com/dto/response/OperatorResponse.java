package com.dto.response;

public class OperatorResponse {

}
