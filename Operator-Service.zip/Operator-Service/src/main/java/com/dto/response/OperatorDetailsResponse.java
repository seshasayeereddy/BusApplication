package com.dto.response;

public class OperatorDetailsResponse {

}
