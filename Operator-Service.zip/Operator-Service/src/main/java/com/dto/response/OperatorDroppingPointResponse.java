package com.dto.response;

public class OperatorDroppingPointResponse {

}
