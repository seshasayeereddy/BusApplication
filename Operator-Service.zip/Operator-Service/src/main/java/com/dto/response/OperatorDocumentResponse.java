package com.dto.response;

public class OperatorDocumentResponse {

}
