package com.dto.response;

public class OperatorApiConfigResponse {

}
