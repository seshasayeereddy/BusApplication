package com.enums;

public class ApiProvider {

}
