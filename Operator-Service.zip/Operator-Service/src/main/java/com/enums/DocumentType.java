package com.enums;

public class DocumentType {

}
