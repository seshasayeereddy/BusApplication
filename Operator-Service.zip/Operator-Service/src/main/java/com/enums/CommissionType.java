package com.enums;

public class CommissionType {

}
