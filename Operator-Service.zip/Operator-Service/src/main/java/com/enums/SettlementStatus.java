package com.enums;

public class SettlementStatus {

}
