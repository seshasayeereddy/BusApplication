package com.enums;

public class OperatorStatus {

}
