package com.enums;

public class VerificationStatus {

}
