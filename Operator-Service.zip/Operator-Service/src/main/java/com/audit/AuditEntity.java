package com.audit;

public class AuditEntity {

}
