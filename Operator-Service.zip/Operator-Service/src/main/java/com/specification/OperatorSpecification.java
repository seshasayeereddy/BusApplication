package com.specification;

public class OperatorSpecification {

}
