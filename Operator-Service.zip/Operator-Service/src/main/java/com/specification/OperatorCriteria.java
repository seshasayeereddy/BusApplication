package com.specification;

public class OperatorCriteria {

}
