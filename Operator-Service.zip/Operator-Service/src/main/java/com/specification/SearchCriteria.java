package com.specification;

public class SearchCriteria {

}
