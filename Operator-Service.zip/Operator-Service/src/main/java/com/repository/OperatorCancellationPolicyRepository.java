package com.repository;

public class OperatorCancellationPolicyRepository {

}
