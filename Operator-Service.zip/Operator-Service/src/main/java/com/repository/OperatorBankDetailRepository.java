package com.repository;

public class OperatorBankDetailRepository {

}
