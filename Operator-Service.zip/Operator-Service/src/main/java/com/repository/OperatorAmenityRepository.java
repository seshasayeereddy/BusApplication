package com.repository;

public class OperatorAmenityRepository {

}
