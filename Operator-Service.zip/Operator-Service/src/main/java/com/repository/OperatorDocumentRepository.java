package com.repository;

public class OperatorDocumentRepository {

}
