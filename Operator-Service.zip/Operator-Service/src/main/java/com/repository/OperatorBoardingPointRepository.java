package com.repository;

public class OperatorBoardingPointRepository {

}
