package com.repository;

public class OperatorVerificationRepository {

}
