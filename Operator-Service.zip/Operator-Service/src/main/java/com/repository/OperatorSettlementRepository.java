package com.repository;

public class OperatorSettlementRepository {

}
