package com.repository;

public class OperatorDroppingPointRepository {

}
