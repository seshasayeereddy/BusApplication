package com.repository;

public class OperatorApiConfigRepository {

}
