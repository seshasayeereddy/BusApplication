package com.config;

public class FeignConfig {

}
