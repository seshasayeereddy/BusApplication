package com.config;

public class JacksonConfig {

}
