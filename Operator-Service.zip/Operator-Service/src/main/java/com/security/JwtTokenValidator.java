package com.security;

public class JwtTokenValidator {

}
