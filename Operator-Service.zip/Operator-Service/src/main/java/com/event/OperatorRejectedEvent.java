package com.event;

public class OperatorRejectedEvent {

}
