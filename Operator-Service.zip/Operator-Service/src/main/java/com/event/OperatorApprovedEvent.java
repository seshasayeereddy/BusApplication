package com.event;

public class OperatorApprovedEvent {

}
