package com.event;

public class OperatorSettlementCompletedEvent {

}
