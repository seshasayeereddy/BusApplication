package com.event;

public class OperatorSuspendedEvent {

}
