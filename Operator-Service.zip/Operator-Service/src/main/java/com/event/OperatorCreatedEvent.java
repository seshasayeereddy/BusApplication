package com.event;

public class OperatorCreatedEvent {

}
