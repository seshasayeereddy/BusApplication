package com.client;

public class MasterDataServiceClient {

}
