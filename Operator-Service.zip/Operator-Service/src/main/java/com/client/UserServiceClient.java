package com.client;

public class UserServiceClient {

}
