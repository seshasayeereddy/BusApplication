package com.client;

public class FileServiceClient {

}
