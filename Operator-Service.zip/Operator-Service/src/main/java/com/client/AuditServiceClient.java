package com.client;

public class AuditServiceClient {

}
