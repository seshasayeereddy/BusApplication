package com.client;

public class NotificationServiceClient {

}
