package com.client;

public class OrangeTravelsClient {

}
