package com.entity;

public class OperatorCancellationPolicy {

}
