package com.entity;

public class OperatorApiConfig {

}
