package com.entity;

public class OperatorDocument {

}
