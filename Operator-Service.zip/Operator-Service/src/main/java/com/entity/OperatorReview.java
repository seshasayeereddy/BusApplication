package com.entity;

public class OperatorReview {

}
