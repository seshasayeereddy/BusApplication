package com.entity;

public class OperatorVerification {

}
