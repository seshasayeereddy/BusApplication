package com.entity;

public class OperatorBankDetail {

}
