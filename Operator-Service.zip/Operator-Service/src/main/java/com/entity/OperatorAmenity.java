package com.entity;

public class OperatorAmenity {

}
