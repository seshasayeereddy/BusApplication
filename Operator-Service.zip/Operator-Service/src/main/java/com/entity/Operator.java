package com.entity;

public class Operator {

}
