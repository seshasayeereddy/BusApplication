package com.entity;

public class OperatorContactPerson {

}
