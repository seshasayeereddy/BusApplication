package com.entity;

public class OperatorCommission {

}
