package com.entity;

public class OperatorBoardingPoint {

}
