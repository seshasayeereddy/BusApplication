package com.entity;

public class OperatorRating {

}
