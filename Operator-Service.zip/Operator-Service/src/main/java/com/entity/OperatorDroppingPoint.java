package com.entity;

public class OperatorDroppingPoint {

}
