package com.entity;

public class OperatorSettlement {

}
