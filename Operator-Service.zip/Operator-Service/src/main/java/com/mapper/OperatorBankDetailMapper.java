package com.mapper;

public class OperatorBankDetailMapper {

}
