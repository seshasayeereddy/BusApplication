package com.mapper;

public class OperatorDroppingPointMapper {

}
