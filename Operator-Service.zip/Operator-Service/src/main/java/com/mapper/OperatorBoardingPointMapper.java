package com.mapper;

public class OperatorBoardingPointMapper {

}
