package com.mapper;

public class OperatorApiConfigMapper {

}
