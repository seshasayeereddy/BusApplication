package com.exception;

public class OperatorAlreadyExistsException {

}
