package com.exception;

public class InvalidOperatorStatusException {

}
