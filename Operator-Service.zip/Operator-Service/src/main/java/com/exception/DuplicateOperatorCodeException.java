package com.exception;

public class DuplicateOperatorCodeException {

}
