package com.exception;

public class OperatorNotFoundException {

}
