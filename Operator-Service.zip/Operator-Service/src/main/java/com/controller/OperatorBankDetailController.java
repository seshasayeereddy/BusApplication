package com.controller;

public class OperatorBankDetailController {

}
