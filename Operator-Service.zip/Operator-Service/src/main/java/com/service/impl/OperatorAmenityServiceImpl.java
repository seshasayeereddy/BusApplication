package com.service.impl;

public class OperatorAmenityServiceImpl {

}
