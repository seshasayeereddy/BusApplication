package com.service.impl;

public class OperatorBankDetailServiceImpl {

}
