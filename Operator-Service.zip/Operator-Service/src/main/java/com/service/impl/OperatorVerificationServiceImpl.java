package com.service.impl;

public class OperatorVerificationServiceImpl {

}
