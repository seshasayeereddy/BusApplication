package com.service;

public class OperatorVerificationService {

}
