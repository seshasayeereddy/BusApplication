package com.service;

public class OperatorBankDetailService {

}
