package com.config;

public class CorsConfig {

}
