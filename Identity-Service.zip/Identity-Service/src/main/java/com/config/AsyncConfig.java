package com.config;

public class AsyncConfig {

}
