package com.config;

public class BeanConfig {

}
