package com.exception.handler;

public class ErrorCode {

}
