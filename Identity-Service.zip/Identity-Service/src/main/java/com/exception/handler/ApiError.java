package com.exception.handler;

public class ApiError {

}
