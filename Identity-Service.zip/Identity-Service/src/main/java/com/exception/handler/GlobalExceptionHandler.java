package com.exception.handler;

public class GlobalExceptionHandler {

}
