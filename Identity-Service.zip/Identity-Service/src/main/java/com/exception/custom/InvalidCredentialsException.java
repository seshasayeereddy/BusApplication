package com.exception.custom;

public class InvalidCredentialsException {

}
