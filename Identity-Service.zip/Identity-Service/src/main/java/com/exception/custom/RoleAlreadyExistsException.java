package com.exception.custom;

public class RoleAlreadyExistsException {

}
