package com.exception.custom;

public class BusinessException {

}
