package com.exception.custom;

public class ResourceNotFoundException {

}
