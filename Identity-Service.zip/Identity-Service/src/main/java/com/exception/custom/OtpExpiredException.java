package com.exception.custom;

public class OtpExpiredException {

}
