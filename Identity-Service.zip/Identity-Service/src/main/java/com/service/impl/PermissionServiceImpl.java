package com.service.impl;

public class PermissionServiceImpl {

}
