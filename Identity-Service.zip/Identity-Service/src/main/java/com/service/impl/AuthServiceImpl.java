package com.service.impl;

public class AuthServiceImpl {

}
