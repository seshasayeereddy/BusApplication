package com.client;

public class EmailServiceClient {

}
