package com.constants;

public class MessageConstants {

}
