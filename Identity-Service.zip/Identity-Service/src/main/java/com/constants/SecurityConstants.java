package com.constants;

public class SecurityConstants {

}
