package com.constants;

public class CacheConstants {

}
