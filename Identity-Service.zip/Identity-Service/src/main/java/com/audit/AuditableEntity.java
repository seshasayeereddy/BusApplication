package com.audit;

public class AuditableEntity {

}
