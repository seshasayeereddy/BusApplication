package com.audit;

public class JpaAuditConfig {

}
