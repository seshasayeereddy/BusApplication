package com.entity;

public class RefreshToken {

}
