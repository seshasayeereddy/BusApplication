package com.entity;

public class Otp {

}
