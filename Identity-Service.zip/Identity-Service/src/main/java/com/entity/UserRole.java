package com.entity;

public class UserRole {

}
