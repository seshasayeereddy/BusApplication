package com.entity;

public class Permission {

}
