package com.enums;

public class OtpType {

}
