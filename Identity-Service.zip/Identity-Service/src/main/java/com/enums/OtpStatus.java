package com.enums;

public class OtpStatus {

}
