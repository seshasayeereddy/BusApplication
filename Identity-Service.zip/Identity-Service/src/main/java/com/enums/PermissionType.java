package com.enums;

public class PermissionType {

}
