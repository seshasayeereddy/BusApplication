package com.enums;

public class TokenType {

}
