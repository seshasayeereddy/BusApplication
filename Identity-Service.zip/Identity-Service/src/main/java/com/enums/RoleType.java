package com.enums;

public class RoleType {

}
