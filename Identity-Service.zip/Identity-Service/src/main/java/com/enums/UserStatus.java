package com.enums;

public class UserStatus {

}
