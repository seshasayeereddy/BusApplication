package com.repository;

public class OtpRepository {

}
