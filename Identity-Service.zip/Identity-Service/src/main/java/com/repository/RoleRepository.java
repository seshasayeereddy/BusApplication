package com.repository;

public class RoleRepository {

}
