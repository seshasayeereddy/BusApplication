package com.repository;

public class RefreshTokenRepository {

}
