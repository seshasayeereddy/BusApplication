package com.repository;

public class PermissionRepository {

}
