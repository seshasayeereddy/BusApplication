package com.repository;

public class UserRoleRepository {

}
