package com.security.userdetails;

public class CustomUserDetailsService {

}
