package com.security.userdetails;

public class CustomUserDetails {

}
