package com.security.entrypoint;

public class JwtAuthenticationEntryPoint {

}
