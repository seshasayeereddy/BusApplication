package com.mapper;

public class PermissionMapper {

}
