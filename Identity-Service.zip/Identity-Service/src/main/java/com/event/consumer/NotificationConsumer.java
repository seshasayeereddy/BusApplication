package com.event.consumer;

public class NotificationConsumer {

}
