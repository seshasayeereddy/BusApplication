package com.event.consumer;

public class EmailConsumer {

}
