package com.event.producer;

public class OtpGeneratedProducer {

}
