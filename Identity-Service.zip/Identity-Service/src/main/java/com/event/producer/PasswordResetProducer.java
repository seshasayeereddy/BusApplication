package com.event.producer;

public class PasswordResetProducer {

}
