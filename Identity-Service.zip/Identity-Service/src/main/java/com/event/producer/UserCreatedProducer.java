package com.event.producer;

public class UserCreatedProducer {

}
