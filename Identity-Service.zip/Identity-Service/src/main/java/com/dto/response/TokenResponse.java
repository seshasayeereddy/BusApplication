package com.dto.response;

public class TokenResponse {

}
