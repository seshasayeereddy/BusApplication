package com.dto.response;

public class RoleResponse {

}
