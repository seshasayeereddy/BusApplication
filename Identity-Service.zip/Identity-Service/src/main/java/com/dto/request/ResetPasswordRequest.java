package com.dto.request;

public class ResetPasswordRequest {

}
