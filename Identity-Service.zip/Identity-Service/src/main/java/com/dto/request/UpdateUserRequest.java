package com.dto.request;

public class UpdateUserRequest {

}
