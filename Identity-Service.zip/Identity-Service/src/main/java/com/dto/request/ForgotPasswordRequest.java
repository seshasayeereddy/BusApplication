package com.dto.request;

public class ForgotPasswordRequest {

}
