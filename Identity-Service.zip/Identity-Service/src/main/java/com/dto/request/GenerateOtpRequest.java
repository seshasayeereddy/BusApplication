package com.dto.request;

public class GenerateOtpRequest {

}
