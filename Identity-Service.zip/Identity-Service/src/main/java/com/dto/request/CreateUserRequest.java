package com.dto.request;

public class CreateUserRequest {

}
