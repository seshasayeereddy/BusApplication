package com.dto.request;

public class CreateRoleRequest {

}
