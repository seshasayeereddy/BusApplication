package com.dto.request;

public class ChangePasswordRequest {

}
