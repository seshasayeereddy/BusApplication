package com.validator;

public class TokenValidator {

}
