package com.validator;

public class EmailValidator {

}
