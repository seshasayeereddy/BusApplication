package com.validator;

public class RoleValidator {

}
