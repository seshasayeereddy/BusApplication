package com.cache;

public class RedisConfig {

}
